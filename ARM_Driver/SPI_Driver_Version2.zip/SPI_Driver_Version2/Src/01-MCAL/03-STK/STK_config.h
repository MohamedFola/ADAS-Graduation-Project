/*
 * STK_config.h
 *
 *  Created on: Feb 1, 2023
 *      Author: speedTECH
 */

#ifndef STK_CONFIG_H_
#define STK_CONFIG_H_
/*
 * Choose:
 * 1.AHB
 * 2.AHB_DIVIDE_BY_8*/
#define STK_CLK_SRC AHB_DIVIDE_BY_8

#endif /* STK_CONFIG_H_ */
