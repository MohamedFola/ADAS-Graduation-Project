#ifndef NVIC_PRIVATE_H
#define NVIC_PRIVATE_H


/*Options to be passed in SetPriority Function to decide how many groups and subgroups*/
#define MNVIC_GROUP4_SUB0			0x05FA0300
#define MNVIC_GROUP3_SUB1 			0x05FA0400
#define MNVIC_GROUP2_SUB2			0x05FA0500
#define MNVIC_GROUP1_SUB3			0x05FA0600
#define MNVIC_GROUP0_SUB4			0x05FA0700



#endif
