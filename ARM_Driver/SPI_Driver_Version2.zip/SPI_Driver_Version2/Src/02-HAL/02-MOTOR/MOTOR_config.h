/*
 * MOT_config.h
 *
 *  Created on: Mar 8, 2023
 *      Author: speedTECH
 */

#ifndef _MOT_CONFIG_H_
#define _MOT_CONFIG_H_



#endif /* _MOT_CONFIG_H_ */
