#ifndef ULTRASONIC_PRIVATE_H
#define ULTRASONIC_PRIVATE_H



#define CH1				1
#define CH2				2
#define CH3				3
#define CH4				4


#endif
