
#include "03-APP/02-ADAS_MAIN/ADAS_interface.h"


#define DISTANCE_MSG_ID    0x771



u32 Current_Time  = 0;
u32 Last_Time     = 0;
u32 Last_Distance = 0;
u32 Distance      = 0;

u32 distanceThreshold = 250;
u8 numOfData = 0 , i =0;
u8 dataRecieved[10];

Rx_t recievedData;


int main (void)
{

	Tx_t trans = {
			.Data = 0 ,
			.DataID = 0X7E1,
			.DataNoBytes = 4,
			.DataType = SPEED
	};

	//	while(1)
	//	{
	//		First_Distance = CommHandlerRxIndication();
	//
	//		Transmit_suc.Data = First_Distance.Data;
	//		Transmit_suc.DataType = First_Distance.DataType;
	//
	//		CommHandlerSend( &Transmit_suc );
	//
	//

	//
	//
	//		MTIM2_voidSetBusyWait( 1100 );
	//	}



	ADAS_VidInit();


	while(1)
	{

		recievedData = CommHandlerRxIndication();

		//		/************************************** De7K ************************************/
		if( recievedData.DataType == DISTANCE )
		{
			if( recievedData.Data > distanceThreshold )
			{
				ADAS_CruiseControl( recievedData.Data );
			}
			else
			{
				ADAS_CollisionAvoidance();
				/* Wait some time then move */
			}
		}
		else
		{
			CommHandlerSend( &trans );
		}
//		else if (recievedData.DataType == STEERING)
//		{
//			ADAS_LaneKeeping(recievedData.Data);
//		}

		//if ( recievedData.DataType == DISTANCE && recievedData.Data < distanceThreshold ) {
	//		ADAS_CollisionAvoidance();
	//	}

		USART_voidTransmitByteSynch( 'D'   , USART1 );
		USART_voidTransmitByteSynch( ':'   , USART1 );
		USART_voidSendNumber( recievedData.Data , USART1 );
		USART_voidTransmitByteSynch( '\r'  , USART1 );
		USART_voidTransmitByteSynch( '\n'  , USART1 );

		USART_voidTransmitByteSynch( 'T'       , USART1 );
		USART_voidTransmitByteSynch( ':'       , USART1 );
		USART_voidSendNumber( recievedData.DataType , USART1 );
		USART_voidTransmitByteSynch( '\r'      , USART1 );
		USART_voidTransmitByteSynch( '\n'      , USART1 );

		MTIM2_voidSetBusyWait( 1100 );

		/*******************************************************************************/
		//			while( (recievedData->DataType == DISTANCE) && (numOfData != 10))
		//			{
		//				dataRecieved[numOfData] = recievedData->Data;
		//				numOfData++;
		//			}
		//
		//			for(i=0 ; i< numOfData ; i++)
		//			{
		//				if( dataRecieved[i+1] > dataRecieved[i])
		//				{
		//					ADAS_CruiseControl(recievedData->Data);
		//					break;
		//				}
		//			}
		//
		//			if(i==numOfData)
		//			{
		//				ADAS_CollisionAvoidance();
		//				/* Wait some time */
		//
		//			}
		//
		//			numOfData = 0;

	}


}

