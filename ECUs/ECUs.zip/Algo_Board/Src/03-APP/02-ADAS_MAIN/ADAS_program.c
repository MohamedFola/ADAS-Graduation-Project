#include "ADAS_interface.h"

void ADAS_VidInit(void)
{
	RCC_voidInitSysClock();
	/******************** GPIOs *******************/
	RCC_voidEnableClock(	RCC_AFIO 	,	RCC_APB2  );
	RCC_voidEnableClock(	RCC_GPIOA	,	RCC_APB2  );
	RCC_voidEnableClock(	RCC_GPIOB	,	RCC_APB2  );
	RCC_voidEnableClock(	RCC_GPIOC	,	RCC_APB2  );
	/******************** SPIs ********************/
	RCC_voidEnableClock(	RCC_SPI1	,	RCC_APB2  );
	/******************* Timers *******************/
	RCC_voidEnableClock(	RCC_TIM2 	,	RCC_APB1  );
	RCC_voidEnableClock(	RCC_TIM3	,	RCC_APB1  );
	RCC_voidEnableClock(	RCC_TIM4	,	RCC_APB1  );
	/******************** USART *******************/
	RCC_voidEnableClock(	RCC_USART1 	,	RCC_APB2  );


	/***************** Port Initialization *****************/
	PORT_voidInit();

	/*************** Timers Initialization *****************/
	MTIM2_voidInit();
	MTIM3_voidInit();


	/**************** USART Initialization *****************/
	USART_config_t uart =
		{
				.USART_Number      = USART1                    ,
				.USART_BaudRate    = USART_BaudRate_9600       ,
				.USART_DataLength  = USART_Data8Bits           ,
				.USART_Parity      = USART_EvenParity          ,
				.USART_ParityCheck = USART_ParityCheckDisabled ,
				.USART_StopBits    = USART_1StopBits
		};
	USART_voidInit(&uart);


	/****************** Communication Handler Initialization *****************/
	CommHandlerInit();
	MCP2515_VidAcceptMSG();
}

void ADAS_CruiseControl( u32 Copy_u8Distance )
{
	u8 Local_u8Speed =0 ;
	Tx_t desiredSpeed = {
			.Data = 0 ,
			.DataID = 0X7E1,
			.DataNoBytes = 4,
			.DataType = SPEED
	};

	Local_u8Speed = ( Copy_u8Distance * 0.198 ) + 30;


	desiredSpeed.Data = Local_u8Speed;
	CommHandlerSend( &desiredSpeed );
}


void ADAS_LaneKeeping(u8 Copy_u8StearingAngle)
{
	u8 Local_u8LeftSpeed =0  , Local_u8RightSpeed = 0 , Local_u8SpeedToSend;
	Tx_t desiredSpeed = {
			.Data = 0 ,
			.DataID = 0X7E1,
			.DataNoBytes = 4,
			.DataType = SPEED
	};

	//[ TensOfLeftSpeed , UnitsOfLeftSpeed , TensOfRightSpeed , UnitsOfRightSpeed ]
	Local_u8SpeedToSend = (Local_u8LeftSpeed*100) + Local_u8RightSpeed;

	desiredSpeed.Data = Local_u8SpeedToSend;
	CommHandlerSend(&desiredSpeed);
}

void ADAS_CollisionAvoidance()
{
	Tx_t desiredSpeed = {
			.Data = 0 ,
			.DataID = 0X7E1,
			.DataNoBytes = 4,
			.DataType = SPEED
	};

	CommHandlerSend(&desiredSpeed);
}
