#ifndef _ADAS_INTERFACE_H
#define _ADAS_INTERFACE_H

#include "../../00-LIB/STD_TYPES.h"
#include "../../00-LIB/BIT_MATH.h"

#include "../../01-MCAL/00-RCC/RCC_interface.h"
#include "../../01-MCAL/01-PORT/PORT_interface.h"
#include "../../01-MCAL/02-DIO/DIO_interface.h"
#include "../../01-MCAL/03-STK/STK_interface.h"
#include "../../01-MCAL/04-NVIC/NVIC_interface.h"
#include "../../01-MCAL/05-EXTI/EXTI_interface.h"
#include "../../01-MCAL/06-AFIO/AFIO_interface.h"
#include "../../01-MCAL/08-TIM/TIM_interface.h"
#include "../../01-MCAL/09-SPI/SPI_interface.h"
#include "../../01-MCAL/11-USART/USART_interface.h"


#include "../../02-HAL/03-MCP/MCP2515_Interface.h"

#include "../../03-APP/01-COMM_HANDLER/CommHandler_interface.h"


void ADAS_VidInit(void);

void ADAS_CruiseControl(u32 Copy_u8Distance);

void ADAS_LaneKeeping(u8 Copy_u8StearingAngle);

void ADAS_CollisionAvoidance();

#endif
