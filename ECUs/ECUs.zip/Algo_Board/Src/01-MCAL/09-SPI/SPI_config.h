/***************************************************************/
/*             Author  : Mohamed Hassan Hassan                 */
/*             Layer   : MCAL                                  */
/*             Version : 1                                     */
/*             SWC     : SPI                                   */
/***************************************************************/

#ifndef _SPI_CONFIG_H_
#define _SPI_CONFIG_H_


#endif /* _SPI_CONFIG_H_ */
