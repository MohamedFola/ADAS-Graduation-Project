/*
 * Motion Board:
 *
 * 		Sensors used:
 * 		1 --> can controller --> SPI2
 * 		2 --> encoders --> TIM2
 *
 * */


/*********** includes ***********/

#include "00-LIB/STD_TYPES.h"
#include "00-LIB/BIT_MATH.h"

#include "01-MCAL/00-RCC/RCC_interface.h"
#include "01-MCAL/01-PORT/PORT_interface.h"
#include "01-MCAL/02-DIO/DIO_interface.h"
#include "01-MCAL/03-STK/STK_interface.h"
#include "01-MCAL/04-NVIC/NVIC_interface.h"
#include "01-MCAL/05-EXTI/EXTI_interface.h"
#include "01-MCAL/08-TIM/TIM_interface.h"
#include "01-MCAL/09-SPI/SPI_interface.h"
#include "01-MCAL/10-PWM/PWM_interface.h"
#include "01-MCAL/11-USART/USART_interface.h"

#include "02-HAL/00-ENC/ENC_interface.h"
#include "02-HAL/02-MOTOR/MOTOR_interface.h"
#include "02-HAL/03-MCP/MCP2515_Interface.h"

#include "03-APP/00-PID/PID.h"
#include "03-APP/01-COMM_HANDLER/CommHandler_interface.h"



#define kp  2.00f
#define ki	0.527f
#define kd	1.05f

#define SETPOINT	0

#define MAX_INTEGRATOR   100.0f
#define MIN_INTEGRATOR  -100.0f

#define MAX_OUTPUT   65.0f
#define MIN_OUTPUT  -65.0f


#define T_SAMPLING	0.001f
#define TAU			0.00f

PID_control pid ={.Kp=kp , .Ki = ki, .Kd= kd,.Max_Limit=MAX_OUTPUT,
		.Min_Limit=MIN_OUTPUT,.Sampling_Time=T_SAMPLING,.Tau=TAU};


#define MOTOR_STOP 0

#define ERRORSIZE 5
u8 ErrorMsg[ ERRORSIZE ] = "Error";


u32 Distance=0;
u32 Last_Distance=0;
s32 Encoder1=0;
s32 Encoder2=0;
s32 Encoder3=0;
s32 Encoder4=0;
s32 Avg_right=0;
s32 Avg_left=0;
s32 setpoint=0;
s32 correction=0;
u8 counter=0;
u16 Last_Time=0;
u8 Speed=75;
u8 flag = 0 ;


int main (void)
{
	/*****************************************************************/
	/**** variable to receive the message from the can controller ****/
	/*****************************************************************/
	Rx_t Receive;


	/***************************/
	/**** motor init struct ****/
	/***************************/
	MOTOR_t Motor =
	{
			.MOTOR_PORT = MDIO_PORTA ,
			.L_DIR_PIN  = MDIO_PIN0  ,
			.R_DIR_PIN  = MDIO_PIN2  ,
			.L_PWM_PIN  = MDIO_PIN1  ,
			.R_PWM_PIN  = MDIO_PIN3
	};


	/********************/
	/**** Clock init ****/
	/********************/
	RCC_voidInitSysClock();
	RCC_voidEnableClock( RCC_GPIOA  , RCC_APB2 );
	RCC_voidEnableClock( RCC_GPIOB  , RCC_APB2 );
	RCC_voidEnableClock( RCC_GPIOC  , RCC_APB2 );
	RCC_voidEnableClock( RCC_TIM2   , RCC_APB1 );
	RCC_voidEnableClock( RCC_TIM3   , RCC_APB1 );
	RCC_voidEnableClock( RCC_TIM4   , RCC_APB1 );
	RCC_voidEnableClock( RCC_AFIO   , RCC_APB2 );
	RCC_voidEnableClock( RCC_SPI2   , RCC_APB1 );
	RCC_voidEnableClock( RCC_USART1 , RCC_APB2 );

	/*******************/
	/**** port init ****/
	/*******************/
	PORT_voidInit();


	/**********************/
	/**** Encoder init ****/
	/**********************/
	HENC_voidInit();

	/*********************/
	/**** timers init ****/
	/*********************/
	MTIM2_voidInit();
	MTIM3_voidInit();
	MTIM4_voidInit();
	MPWM2_voidInit();
	MPWM3_voidInit();

	/***************************/
	/**** usart init struct ****/
	/***************************/
	USART_config_t uart =
	{
			.USART_Number      = USART1                    ,
			.USART_BaudRate    = USART_BaudRate_9600       ,
			.USART_DataLength  = USART_Data8Bits           ,
			.USART_Parity      = USART_EvenParity          ,
			.USART_ParityCheck = USART_ParityCheckDisabled ,
			.USART_StopBits    = USART_1StopBits
	};

	/********************/
	/**** usart init ****/
	/********************/
	USART_voidInit( &uart );


	/****************************/
	/**** communication init ****/
	/****************************/
	CommHandlerInit();

	PID_init(&pid);

	MTIM2_voidSetBusyWait( 1 );
	MTIM2_voidSetBusyWait( 50000 );

	MTIM3_voidStartCounter();
	MTIM4_voidStartCounter();


	while(1)
	{
		/*Encoder 4 --> RF	 		Encoder 1 --> RB*/
		/*Encoder 3 --> LB	 		Encoder 2 --> LF*/

		Encoder1 = Absolute( HENC_u8Enc1GetCounts() ); //right
		Encoder2 = Absolute( HENC_u8Enc2GetCounts() ); //left
		Encoder3 = Absolute( HENC_u8Enc3GetCounts() ); //left
		Encoder4 = Absolute( HENC_u8Enc4GetCounts() ); //right
		//		HULTRASONIC_voidGetDistance(&ultra, &Distance);



		u16 Current_Time = MTIM3_u16GetRemainingTime();

		if( Last_Time > 64999 )
		{
			Last_Time = 0;
		}

		if( Absolute( Current_Time  -  Last_Time ) >= 1150 )
		{
			Last_Time =MTIM3_u16GetRemainingTime();

			Avg_right = ( Encoder1 + Encoder4 )/2;
			Avg_left =  ( Encoder2 + Encoder3 )/2;


			Receive = CommHandlerRxIndication();


			correction = PID_controller_calc( &pid, SETPOINT , Avg_left - Avg_right );

			MOTOR_voidMove( &Motor , MOTOR_FORWARD, ( 80 + correction) , ( 80 - correction ) );


			//			if( Receive.Data != 0 && Receive.DataType == SPEED )
			//			{
			//				MOTOR_voidMove( &Motor , MOTOR_FORWARD, ( Receive.Data + correction) , ( Receive.Data - correction ) );
			//			}
			//			else if ( Receive.Data == 0 && Receive.DataType == SPEED )
			//			{
			//				MOTOR_voidMove( &Motor, MOTOR_FORWARD, 0, 0 );
			//				Encoder1 = 0;
			//				Encoder2 = 0;
			//				Encoder3 = 0;
			//				Encoder4 = 0;
			//				Avg_left = 0  ;
			//				Avg_right = 0 ;
			//				correction = 0;
			//			}


			// UART for Correction
			//			USART_voidTransmitByteSynch('E', USART1);
			//			USART_voidTransmitByteSynch('4', USART1);
			//			USART_voidTransmitByteSynch(':', USART1);
			//			USART_voidSendNumber(Encoder4, USART1);
			//			USART_voidTransmitByteSynch('\r', USART1);
			//			USART_voidTransmitByteSynch('\n', USART1);
			//
			//
			//			USART_voidTransmitByteSynch('E', USART1);
			//			USART_voidTransmitByteSynch('2', USART1);
			//			USART_voidTransmitByteSynch(':', USART1);
			//			USART_voidSendNumber(Encoder2, USART1);
			//			USART_voidTransmitByteSynch('\r', USART1);
			//			USART_voidTransmitByteSynch('\n', USART1);


			USART_voidTransmitByteSynch( 'A' , USART1 );
			USART_voidTransmitByteSynch( 'L' , USART1 );
			USART_voidTransmitByteSynch( ':' , USART1 );
			USART_voidSendNumber( Avg_left , USART1 );
			USART_voidTransmitByteSynch( '\r' , USART1 );
			USART_voidTransmitByteSynch( '\n' , USART1 );

			USART_voidTransmitByteSynch( 'A' , USART1 );
			USART_voidTransmitByteSynch( 'R' , USART1 );
			USART_voidTransmitByteSynch( ':' , USART1 );
			USART_voidSendNumber( Avg_right , USART1 );
			USART_voidTransmitByteSynch( '\r' , USART1 );
			USART_voidTransmitByteSynch( '\n' , USART1 );

			USART_voidTransmitByteSynch( 'D' , USART1 );
			USART_voidTransmitByteSynch( ':' , USART1 );
			USART_voidSendNumber( Avg_right - Avg_left , USART1 );
			USART_voidTransmitByteSynch( '\r' , USART1 );
			USART_voidTransmitByteSynch( '\n' , USART1 );

			USART_voidTransmitByteSynch( 'C' , USART1 );
			USART_voidTransmitByteSynch( ':' , USART1 );
			USART_voidSendNumber( correction , USART1 );
			USART_voidTransmitByteSynch( '\r' , USART1 );
			USART_voidTransmitByteSynch( '\n' , USART1 );


			//			USART_voidTransmitByteSynch( 'S' , USART1 );
			//			USART_voidTransmitByteSynch( ':' , USART1 );
			//			USART_voidSendNumber( Receive.Data , USART1 );
			//			USART_voidTransmitByteSynch( '\r' , USART1 );
			//			USART_voidTransmitByteSynch( '\n' , USART1 );

			USART_voidTransmitByteSynch( '\r' , USART1 );
			USART_voidTransmitByteSynch( '\n' , USART1 );


			// UART for Received data
			//			USART_voidTransmitByteSynch( 'D'   , USART1 );
			//			USART_voidTransmitByteSynch( ':'   , USART1 );
			//			USART_voidSendNumber( Receive.Data , USART1 );
			//			USART_voidTransmitByteSynch( '\r'  , USART1 );
			//			USART_voidTransmitByteSynch( '\n'  , USART1 );
			//
			//			USART_voidTransmitByteSynch( 'T'       , USART1 );
			//			USART_voidTransmitByteSynch( ':'       , USART1 );
			//			USART_voidSendNumber( Receive.DataType , USART1 );
			//			USART_voidTransmitByteSynch( '\r'      , USART1 );
			//			USART_voidTransmitByteSynch( '\n'      , USART1 );

		}
	}
}
