#include "PID.h"
#include "../../01-MCAL/08-TIM/TIM_interface.h"
#include "../../01-MCAL/11-USART/USART_interface.h"
void PID_init(PID_control *pid)
{
	pid->Integrator = 0.0f;
	pid->prevError  = 0;

	pid->differentiator  = 0.0f;
	pid->prevMeasurement = 0;

	pid->output = 0;

}

u32 Absolute(s32 number)
{
	if(number<0)
	{
		return (-1*(number));
	}
	else
	{
		return number;
	}
}
s32 PID_controller_calc(PID_control *pid, s32 setpoint ,s32 RT_measurment)
{
	s32 error;
	f32 propotional;
	s32 dt	= 0 ;
	static u16 Last_Time=0;

	u16 Current_Time = MTIM4_u16GetRemainingTime();

	dt = (Current_Time - Last_Time ) / 1000 ;

	error = setpoint - RT_measurment;

	propotional= (pid->Kp)*error;
//	return (s32)propotional;

	if(Last_Time)
	{

		pid -> Integrator += error*dt;
//		pid -> differentiator = ( RT_measurment - pid ->prevMeasurement )  ;
		pid -> differentiator = ( error - pid ->prevError )  ;
		/*Clamping of integrator*/
		if(pid -> Integrator > pid -> Max_Integrator_Limit )
		{
			pid -> Integrator =pid -> Max_Integrator_Limit;
		}
		else if(pid -> Integrator < pid -> Min_Integrator_Limit )
		{
			pid -> Integrator =pid -> Min_Integrator_Limit;
		}
		pid -> differentiator /= dt;
		pid -> output= propotional + ((pid -> Ki )*(pid -> Integrator)) + ((pid -> Kd)*(pid -> differentiator));

		/*clamping the output*/
		if(pid->output >pid-> Max_Limit)
		{
			pid -> output =pid -> Max_Limit;
		}
		else if(pid->output < pid->Min_Limit)
		{
			pid -> output = pid -> Min_Limit;
		}

	}
	/*restoring the last error and measurement*/

	Last_Time = Current_Time ;
	pid -> prevError =error;
	pid -> prevMeasurement= RT_measurment;


  return (s32)propotional;

}


